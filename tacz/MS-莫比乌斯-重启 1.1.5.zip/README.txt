鸣谢：
tacz官方的部分动画模型资产

LeComte脖撅柿伯爵、LESHUAN_20乐拴
动画资产支援

Rhodes_koei、黄毛白鼠鼠
状态机技术支持

有德79、AstralLin、LonelyBoy3540
配件资产支援

时了个大雨
动画修复协助、状态机技术支持

CimaSilchin-神梦星辰
热于助人的大肥猫，模型及动画资产支援

本枪包部分资产归属tacz开发组及上述附属包成员，严禁将本枪包内容用于任何盈利用途！

